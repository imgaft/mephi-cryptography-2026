import sys
from pathlib import Path
import pytest
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from main import ALPHABET, ALPHABET_1, ALPHABET_3, encrypt, decrypt, validate_alphabets

def test_alphabets():
    validate_alphabets()
    assert len(ALPHABET) == len(ALPHABET_1) == len(ALPHABET_3) == 34

def test_encrypt():
    assert encrypt("ПРИВЕТ") == "СЯЦМЬЭ"

def test_decrypt():
    assert decrypt("СЯЦМЬЭ") == "ПРИВЕТ"

def test_encrypt_decrypt():
    assert decrypt(encrypt("ПРИВЕТ МИР")) == "ПРИВЕТ МИР"

def test_spaces():
    assert decrypt(encrypt("А Б")) == "А Б"

def test_lowercase():
    assert decrypt(encrypt("привет")) == "ПРИВЕТ"

def test_invalid_character():
    with pytest.raises(ValueError):
        encrypt("ПРИВЕТ!")

def test_empty_string():
    assert encrypt("") == decrypt("") == ""
